﻿hidriv.loadPage(function (pageContEle, app) {

    $("body").attr("data-layout", "hasmenu");

    var app = app;
    var timing = app.timing;
    var pageContEle = pageContEle;
    var components = app.components;
    var storage = app.currentEvent.storage;
    var cache = app.currentEvent.cache;
    var fileName = app.currentEvent.fileName;

    /************************/
    /*** LAYOUT     *********/
    /************************/

    var layout = new components.Layout({
        resize: false
    });

    var leftCol = layout.addColumn({ scrollable: true });
    pageContEle.append(layout.html);


    /************************/
    /*** RESULTS GRIDs ******/
    /************************/

    var ResultsByCategoryGrid = views.ResultsByCategoryGrid; 
    $.each(cache.PodiumCategory.id, function (id, obj) {
        var resultsGrid = new ResultsByCategoryGrid(obj,app.currentEvent,timing,components.Toolbar,components.Grid);
        var resultsGridCell = leftCol.addCell();
        resultsGrid.toolbar.addButton("Print", function () {
            window.open("html/results-print.html?fileName=" + fileName + "&categoryId=" + obj.id, "_blank");
        });
        resultsGridCell.pad.append(resultsGrid.html);
    });
    
});