﻿




$(document).ready(function () {
   
    var lib = new Lib();
    var timing = new Timing();
    var components = new Components();
    var fileName = lib.getURLParam("fileName");
    //var printByEnum = lib.getURLParam("printByEnum");
    var cache = DataTemplate.cacheTemplate;
    var eventTemplate = DataTemplate.eventTemplate;
    var storage;

    var domFileStorage = new DOMFileStorage(function () {
        domFileStorage.readFile(fileName, function (fileContents) {
            var ev = JSON.parse(fileContents);
            storage = new MemoryStorage(ev.storage, ev.model, ev.primaryKey, cache, function () { });
            
            var currentEvent = new Event(ev, cache, domFileStorage, eventTemplate);
            
            var grid = new components.Grid({
                selectable: true,
                rowKey: "id",
                columns: [
                    { label: "Bib", dataKey: "bib" },
                    { label: "F Name", dataKey: "firstName" },
                    { label: "L Name", dataKey: "lastName" },
                    { label: "Age", dataKey: "age" },
                    { label: "Team", dataKey: "team" },
                    {
                        label: "Category", dataKey: "podiumCategoryId", getValue: function (podiumCategoryId) {
                            return (podiumCategoryId) ? currentEvent.cache.PodiumCategory.id[podiumCategoryId].name : "";
                        }
                    }
                ]
            });
            grid.clear();
            $.each(currentEvent.cache.Racer.bib, function (i, racer) {
                grid.addRow(racer);
            });

            var head = grid.html.find(".head");
            head.remove();
            var tr = head.find("tr");
            setTimeout(function () {
                grid.html.find("table").prepend($("<thead>", { html: tr }));

                $("#print_btn").click(function () {
                    window.print();
                });
                $("#close_btn").click(function () {
                    chrome.app.window.current().close();
                });
            }, 900);
            $("title").html("Racer List - hidriv timing");

            $("#print_cont").append(grid.html);
            $(".toolbar").append($("<img>", { src: "../imgs/hidriv_logo.png", "class": "print-logo" }));
        });
    });

});