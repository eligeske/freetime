﻿
window.open = function (url) {
    chrome.app.window.create(url, {
        frame: "none",
        'bounds': {
            'width': 700,
            'height': 900
        }
    }, function (appWindow) {

    });
}

window.confirm = function (message,callback) {
    var popup = new components.Popup({
        height: 100, width: 300
    });
    popup.body.append("<div style='color: #fff; padding: 15px;'>" + message + "</div>");
    popup.addButton("Yes", function () {
        callback();
        popup.close();
    });
    popup.addButton("No", function () {
        popup.close();
    });
    popup.open();
}


var openEventFile = function (fileName) {
    window.fileName = fileName;
    $("[data-page='entry']").hide();
    $("[data-page='timing']").show();
    fileStorage = new FileStorage(function () {
        fileStorage.readFile(fileName, function (fileContents) {
            hidriv = JSON.parse(fileContents);
            __construct();
        });
    });
}
var closeEventFile = function () {
    window.fileName = null;
    $("#event_name").text('');
    $("[data-page='timing']").hide();
    $("[data-page='entry']").show();
}
var fileStorage;
var hi = {
    alert: function (text) {
        var al = $("<div>", { "class": "alert" });
        if (text instanceof Array) {
            $.each(text, function (i, val) {
                al.append("<span>" + val + "</span>");
            });
        } else {
            al.append("<span>" + text + "</span>");
        }
        $("body").append(al);
        al.delay(3000).fadeOut("slow", function () { al.remove(); });
    }
}
$(function () {
    $(document.body).delegate(":input", "keydown", function (e) {
        var k = e.which;
        var no = ["/", "*", "-", "+"];
        if ((k > 64 && k < 91) || k == 46 || (k > 36 && k < 41) || (k > 96 && k < 123) || k == 8 || (k > 47 && k < 58) || (k == 96)) {
            return true;
        } else if (k <= 32 && (k >= 48 || k <= 57) && k != 107 && k != 111 && k != 109) {
            return true;
        }
        hi.alert("Only letters and numbers can be typed into the system.");
        return false;
    });

});
var views = {};
var hidriv = {};
var cache = {
    Racer: {
        id: {},
        bib: {}
    },
    PodiumCategory: {
        id: {}
    },
    RacerStart: {
        racerId: {}
    },
    CategoryStart: {
        podiumCategoryId: {}
    }
};
var timing = new Timing();
var components = new Components();
var storage;
var loadPage = function (callback) {
    $("#page_cont").html('');
    callback($("#page_cont"));
}
var __construct = function () {
    storage = new Storage(hidriv.event.storage,
        hidriv.event.model, hidriv.event.primaryKey, cache, function () {
            var stfy = JSON.stringify(hidriv);
            JSON.parse(stfy);
            fileStorage.writeFile(fileName, JSON.stringify(hidriv), function () {
                fileStorage.readFile(fileName, function (fileContents) {
                    JSON.parse(fileContents);
                });
            });
        });
    setTitleBar();
    onHashChange();
    bindEvents();
    (hidriv.event.settings.timingType == "single-start") ? $("#menu_single_start").show() : $("#menu_category_start").show()
}

var setTitleBar = function () {
    $("#event_name").text(hidriv.event.settings.name);
}
var onHashChange = function () {
    if (!location.hash) { return; }
    lib.getJS("pages/" + (location.hash.split("#")[1]) + ".js", function () {
        $(".menu-item").removeClass("active");
        $("[href='" + location.hash + "']").addClass("active");
    });
}
var bindEvents = function () {
    $(window).on("hashchange", function () {
        onHashChange();
    });
}
