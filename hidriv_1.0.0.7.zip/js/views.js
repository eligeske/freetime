﻿var views = {
    ResultsByCategoryGrid : function (podiumCategoryObj,currentEvent,timing,Toolbar,Grid) {
        var self = this;
        
        var Toolbar = Toolbar;
        var Grid = Grid;

        var timing = timing;
        var storage = currentEvent.storage;
        var cache = currentEvent.cache;
        var eventSettings = currentEvent.settings;

        var podiumCategoryObj = podiumCategoryObj;
        var html;
        var toolbar;
        var grid;
        var category;
        var ResultModel = function () {
            this.bib = "";
            this.rank = "";
            this.firstName = "";
            this.lastName = "";
            this.completedLaps = 0;
            this.overallHumanTime = "";
        };

        var __construct = function () {
            createHtml();
            createToolbar();
            createGrid();
            addLaps();
            self.html = html;
            self.toolbar = toolbar;
            self.grid = grid;
        }

        var createHtml = function () {
            html = $("<div>");
        }

        var createToolbar = function () {
            toolbar = new Toolbar(podiumCategoryObj.name);
            html.append(toolbar.html);
        }

        var createGrid = function () {
            var gridSettings = {
                //selectable: true,
                rowKey: "racerId",
                columns: [
                    { label: "Place", dataKey: "rank", width: 45, "class":"place-column" },
                    //{ label: "RacerId", dataKey: "racerId", width: 45, visible: false },
                    { label: "Bib", dataKey: "bib", "class": "bib-column" },
                    { label: "F Name", dataKey: "firstName", "class": "fname-column" },
                    { label: "L Name", dataKey: "lastName", "class": "lname-column" },
                    { label: "Age", dataKey: "age", "class": "age-column" },
                    { label: "Team", dataKey: "team", "class": "team-column" }
                ]
            }

            for (var i = 1; i <= podiumCategoryObj.numberOfLaps; i++) {
                ResultModel.prototype["lap" + i] = "";
                gridSettings.columns.push({ dataKey: "lap" + i, label: "Lap " + i, "class": "lap-column" });
            }
            gridSettings.columns.push({ dataKey: "overallHumanTime", label: "total", "class": "total-column" });
            gridSettings.columns.push({ dataKey: "completedLaps", label: "#laps", "class": "laps-column" });
            grid = new Grid(gridSettings);
            html.append(grid.html);
        }

        var addLaps = function () {
            getResults(function (results) {
                grid.loadData(results);
            });
        }

        var getResults = function (callback) {
            var results = [];
            getLapAndRacerData(function (laps, racers) {
                new Promise(function (resolve, reject) {
                    $.each(racers, function (i, racer) {
                        var startTimestamp = (eventSettings.timingType == "single-start") ? 
                            cache.RacerStart.racerId[racer.id].timestamp : cache.CategoryStart.podiumCategoryId[racer.podiumCategoryId].timestamp;
                        var res = new ResultModel();
                        res.racerId = racer.id;
                        res.bib = racer.bib;
                        res.firstName = racer.firstName;
                        res.lastName = racer.lastName;
                        res.age = racer.age;
                        res.team = racer.team;
                        var racerLaps = [];

                        $.each(laps, function (ii, lap) {
                            if (lap.racerId == racer.id) {
                                lap.lapNumber = (racerLaps.length) ? racerLaps.length + 1 : 1;
                                if (lap.lapNumber > podiumCategoryObj.numberOfLaps) { return; }
                                var prevTimestamp = (lap.lapNumber == 1) ? startTimestamp : racerLaps[lap.lapNumber - 2].timestamp;
                                lap.lapMS = lap.timestamp - prevTimestamp;

                                res["lap" + lap.lapNumber] = timing.getReadableTime(lap.lapMS);
                                racerLaps.push(lap);
                                res.completedLaps++;
                                if (lap.lapNumber == podiumCategoryObj.numberOfLaps) {
                                    res["overallMS"] = lap.timestamp - startTimestamp;
                                    res["overallHumanTime"] = timing.getReadableTime(res["overallMS"]);
                                }
                            }
                        });

                        results.push(res);
                    });
                    // sort results
                    results.sort(function (a, b) {
                        if (a.completedLaps !== b.completedLaps) {
                            return a.completedLaps < b.completedLaps;
                        } else {
                            return a.overallMS > b.overallMS
                        }
                    });

                    $.each(results, function (i, res) {
                        res.rank = (res.overallHumanTime != "DNF") ? i + 1 : "";
                    });

                    resolve(results);
                }).then(function (results) {
                    callback(results);
                });
            });
        }

        var getLapAndRacerData = function (callback) {
            storage.Racer.readMany("podiumCategoryId", podiumCategoryObj.id, function (racers) {
                var bibArray = lib.arrayOfValues(racers, "bib");
                storage.Lap.readMany("bib", bibArray, function (laps) {
                    callback(laps, racers);
                });
            });
        }

        __construct();

    }
}