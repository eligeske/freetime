﻿hidriv.loadPage(function (pageContEle, app) {

    $("body").attr("data-layout", "hasmenu");

    var timing = app.timing;
    var components = app.components;
    var storage = app.currentEvent.storage;
    var cache = app.currentEvent.cache;
    var model = app.currentEvent.model;

    /************************/
    /*** LAYOUT     *********/
    /************************/

    var layout = new components.Layout();

    var leftCol = layout.addColumn();
    var startCell = leftCol.addCell();
    startCell.setHeight(220);
    var lapGridCell = leftCol.addCell();
    pageContEle.append(layout.html);


    /************************/
    /*** START VIEW *********/
    /************************/
    
    var singleStartView = new (function () {
        var self = this;
        var html;
        var nameDiv;
        var bibInp;
        var store = storage.Lap;
        var Model = function () { return $.extend(this, model.Lap); };

        var __construct = function () {
            createHtml();
            bindEvents();
            self.html = html;
        }
        // EVENTS
        var bindEvents = function () {
            bibInp.keyup(function (e) {
                onBibKeyUp($(this).val());
                if (e.which == 13) {
                    onStartClick();
                }
            });
        }
        // ACTIONS
        var onStartClick = function () {
            var bib = bibInp.val();
           
            var data = new Model();
            data.timestamp = timing.getTimeStamp();

            if (cache.Racer.bib[bib]) {
                lib.updateObject(data, cache.Racer.bib[bib], { "racerId": "id" });
            }

            store.insert(data, function () {
                bibInp.val(''); nameDiv.html('');
            });
        }
        var onBibKeyUp = function (bibNumber) {
            if (bibNumber && cache.Racer.bib[bibNumber]) {
                nameDiv.html(cache.Racer.bib[bibNumber].firstName + " " + cache.Racer.bib[bibNumber].lastName);
            } else {
                nameDiv.html('no racer found');
            }
        }
        // METHODS
        var createHtml = function () {
            html = $("<div>", { "class": "single-start grid" });
            var table = $("<table>", { "class": "head", html: "<thead><tr><th>Lap Entry</th></tr></thead>" });
            var body = $("<tbody>", { html: "<tr><td></td></tr>" });
            table.append(body);
            var td = body.find('td');

            nameDiv = $("<div>", { "class": "name-display" });
            var form = $("<div>", { style: "padding: 15px 45px;" });
            bibInp = $("<input>", { "class": "bib-input", placeholder: "Enter BIB #" });
            var btn = $("<button>", { "class": "bib-input start-btn", html: "add lap", click: onStartClick });
            var instr = $("<div>", { "class": "instructions", html: "Type in the Bib # and press Enter or click the Start button." });
            form.append(instr, bibInp, btn, nameDiv);
            td.append(form);
            html.append(table);
        }


        __construct();
    })();

    startCell.pad.append(singleStartView.html);


    /************************/
    /*** LAP GRID ***********/
    /************************/

    var lapGrid = new components.EditorGrid({
        container: lapGridCell.pad,
        title: "Laps",
        store: storage.Lap,
        refreshGrid: function(store,grid){
            store.readAll(function (data) {
                data = _.sortBy(data, function (obj) { return obj.timestamp; });
                data.reverse();
                grid.loadData(data);
            });
        },
        gridSettings: {
            selectable: true,
            rowKey: "id",
            columns: [
                { label: "Id", dataKey: "id", hidden: true },
                { label: "RacerId", dataKey: "racerId", hidden: true },
                { label: "BIB", dataKey: "bib" },
                //{ label: "Timestamp", dataKey: "timestamp" },
                {
                    label: "Time", dataKey: "timestamp", getValue: function (timestamp) {
                        return timing.getReadableClockFromTimestamp(timestamp);
                    }
                },
                {
                    label: "F Name", dataKey: "racerId", getValue: function (racerId) {
                        return (racerId) ? cache.Racer.id[racerId].firstName : "";
                    }
                },
                {
                    label: "L Name", dataKey: "racerId", getValue: function (racerId) {
                        return (racerId) ? cache.Racer.id[racerId].lastName : "";
                    }
                },
            ]
        },
        popupSettings: { height: 200, width: 320 },
        formSettings: {
            fields: [
                    { label: "id", dataKey: "id", readonly: true, visible: true },
                    { label: "RacerId", dataKey: "racerId", readonly: true },
                    { label: "Bib", dataKey: "bib" },
                    { label: "Timestamp", dataKey: "timestamp", dataType: "int" },
            ]
        }
    }, components.Toolbar, components.Grid, components.Popup, components.Form);

    lapGrid.toolbar.html.find(".button").hide();
    lapGrid.onFormCreated(function (form) {
        form.html.find("[name='bib']").on("keyup", function () {
            var bib = $(this).val();
            var r = cache.Racer.bib[bib];
            if (r) {
                var data = {
                    racerId: r.id
                }
                lib.fillForm(form.html,data);
            }
        });
    });

    storage.Lap.listen(lapGrid, function () {
        lapGrid.refreshGrid();
    });

    // RESIZE LAYOUT
    layout.resize();

});