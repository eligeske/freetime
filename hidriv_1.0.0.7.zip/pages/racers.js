﻿hidriv.loadPage(function (pageContEle, app) {

    $("body").attr("data-layout", "hasmenu");

    var components = app.components;
    var storage = app.currentEvent.storage;
    var cache = app.currentEvent.cache;
    var fileName = app.currentEvent.fileName;

    /************************/
    /*** LAYOUT     *********/
    /************************/

    var layout = new components.Layout();
    
    var leftCol = layout.addColumn();
    var categoryGridCell = leftCol.addCell();
    categoryGridCell.setHeight(275);
    var racerGridCell = leftCol.addCell();    
    pageContEle.append(layout.html);
    
    /************************/
    /*** PODIUM CAT GRID ****/
    /************************/

    var categoryGrid = new components.EditorGrid({
        container: categoryGridCell.pad,
        title: "Categories",
        store: storage.PodiumCategory,
        gridSettings: {
            selectable: true,
            rowKey: "id",
            columns: [
                { label: "Id", dataKey: "id", hidden: true },
                { label: "Name", dataKey: "name" },
                { label: "# of Laps", dataKey: "numberOfLaps" }
            ]
        },
        popupSettings: { height: 200, width: 320 },
        formSettings: {
            fields: [
                    { label: "id", dataKey: "id", readonly: true, visible: true },
                    { label: "Name", dataKey: "name" },
                    { label: "# of Laps", dataKey: "numberOfLaps" },
            ]
        }
    },components.Toolbar,components.Grid,components.Popup,components.Form);


    /************************/
    /*** RACER GRID *********/
    /************************/
    
    var getCategoryOptions = function (callback) {
        storage.PodiumCategory.readAll(function (data) {
            var options = [];
            $.each(data, function (i, dataRow) {
                options.push(lib.mapObject(dataRow, { "label": "name", "value": "id" }));
            });
            callback(options);
        });
    }
    var racerGrid = new components.EditorGrid({
        container: racerGridCell.pad,
        title: "Racers",
        store: storage.Racer,
        gridSettings: {
            selectable: true,
            rowKey: "id",
            columns: [
                { label: "Id", dataKey: "id", hidden: true },
                { label: "Bib", dataKey: "bib" },
                { label: "F Name", dataKey: "firstName" },
                { label: "L Name", dataKey: "lastName" },
                { label: "Age", dataKey: "age" },
                { label: "Team", dataKey: "team" },
                {
                    label: "Category", dataKey: "podiumCategoryId", getValue: function (podiumCategoryId) {
                        return (podiumCategoryId)?cache.PodiumCategory.id[podiumCategoryId].name:"";
                    }
                }
            ]
        },
        popupSettings: { height: 300, width: 320 },
        formSettings: {
            fields: [
                { label: "Id", dataKey: "id", readonly: true, hidden: true },
                {
                    label: "Bib", dataKey: "bib", required: true, valid: function (formData) {
                        if (cache.Racer.bib[formData.bib] && cache.Racer.bib[formData.bib].id != formData.id) {
                            return "This bib number is already assigned to another Racer.";
                        }
                        return true;
                    }
                },
                { label: "F Name", dataKey: "firstName", required: true },
                { label: "L Name", dataKey: "lastName", required: true },
                { label: "Age", dataKey: "age", required: true },
                { label: "Team", dataKey: "team" },
                { label: "Category", dataKey: "podiumCategoryId", type: "select", getOptions: getCategoryOptions, required: true }
            ]
        }
    }, components.Toolbar, components.Grid, components.Popup, components.Form);
    

    racerGrid.toolbar.addButton("Print", function () {
        window.open("html/racers-print.html?fileName=" + fileName + "&printType=printAll" , "_blank");

    });


    storage.PodiumCategory.listen(racerGrid, function () {
        racerGrid.refreshGrid();
    });

    
    
    

   
    
    // RESIZE LAYOUT
    layout.resize();

});