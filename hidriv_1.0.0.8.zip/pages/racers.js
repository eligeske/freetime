﻿hidriv.loadPage(function (pageContEle, app) {

    $("body").attr("data-layout", "hasmenu");

    var components = app.components;
    var storage = app.currentEvent.storage;
    var cache = app.currentEvent.cache;
    var fileName = app.currentEvent.fileName;

    /************************/
    /*** LAYOUT     *********/
    /************************/

    var layout = new components.Layout();
    
    var leftCol = layout.addColumn();
    var categoryGridCell = leftCol.addCell();
    categoryGridCell.setHeight(275);
    var racerGridCell = leftCol.addCell();    
    pageContEle.append(layout.html);
    
    /************************/
    /*** PODIUM CAT GRID ****/
    /************************/

    var categoryGrid = new components.EditorGrid({
        container: categoryGridCell.pad,
        title: "Categories",
        store: storage.PodiumCategory,
        gridSettings: {
            selectable: true,
            rowKey: "id",
            columns: [
                { label: "Id", dataKey: "id", hidden: true },
                { label: "Name", dataKey: "name" },
                { label: "# of Laps", dataKey: "numberOfLaps" }
            ]
        },
        popupSettings: { height: 140, width: 320 },
        formSettings: {
            fields: [
                    { label: "id", dataKey: "id", readonly: true, visible: false },
                    { label: "Name", dataKey: "name", required: true },
                    { label: "# of Laps", dataKey: "numberOfLaps", required: true }
            ]
        }
    },components.Toolbar,components.Grid,components.Popup,components.Form);


    /************************/
    /*** RACER GRID *********/
    /************************/
    
    var getCategoryOptions = function (callback) {
        storage.PodiumCategory.readAll(function (data) {
            var options = [];
            $.each(data, function (i, dataRow) {
                options.push(lib.mapObject(dataRow, { "label": "name", "value": "id" }));
            });
            callback(options);
        });
    }
    var racerGrid = new components.EditorGrid({
        container: racerGridCell.pad,
        title: "Racers",
        store: storage.Racer,
        gridSettings: {
            selectable: true,
            rowKey: "id",
            columns: [
                { label: "Id", dataKey: "id", hidden: true },
                { label: "Bib", dataKey: "bib" },
                { label: "F Name", dataKey: "firstName" },
                { label: "L Name", dataKey: "lastName" },
                { label: "Age", dataKey: "age" },
                { label: "Team", dataKey: "team" },
                {
                    label: "Category", dataKey: "podiumCategoryId", getValue: function (podiumCategoryId) {
                        return (podiumCategoryId)?cache.PodiumCategory.id[podiumCategoryId].name:"";
                    }
                }
            ]
        },
        popupSettings: { height: 300, width: 320 },
        formSettings: {
            fields: [
                { label: "Id", dataKey: "id", readonly: true, hidden: true },
                {
                    label: "Bib", dataKey: "bib", required: true, valid: function (formData) {
                        if (cache.Racer.bib[formData.bib] && cache.Racer.bib[formData.bib].id != formData.id) {
                            return "This bib number is already assigned to another Racer.";
                        }
                        return true;
                    }
                },
                { label: "F Name", dataKey: "firstName", required: true },
                { label: "L Name", dataKey: "lastName", required: true },
                { label: "Age", dataKey: "age", required: true },
                { label: "Team", dataKey: "team" },
                { label: "Category", dataKey: "podiumCategoryId", type: "select", getOptions: getCategoryOptions, required: true }
            ]
        }
    }, components.Toolbar, components.Grid, components.Popup, components.Form);
    

    racerGrid.toolbar.addButton("Print", function () {
        printByCatPopup.open();

    });


    storage.PodiumCategory.listen(racerGrid, function () {
        racerGrid.refreshGrid();
    });

    




    /*****************************************/
    /****** PRINT BY CAT POPUP ***************/
    /*****************************************/

    var allCatsRowKey = "all-categories";

    var openEventClick = function (rowKey) {
        //printByCatPopup.close();
        var printUrl = "html/racers-print.html?fileName=" + fileName + "&printType=";
        if (rowKey === allCatsRowKey) {
            printUrl += racersPrintType.all;
        } else {
            printUrl += racersPrintType.byCategory + "&categoryId=" + rowKey;
        }
        window.open(printUrl, "_blank");
    }

    var selectCatGrid = new app.components.Grid({
        selectable: "single",
        rowKey: "id",
        columns: [
            { label: "Id", dataKey: "id", hidden: true },
            { label: "Print Racers (dbl click row)", dataKey: "name", onDblClick: openEventClick }
        ]
    });

    var printByCatPopup = new app.components.Popup({
        height: 200, width: 365
    });

    var refreshCatList = function () {
        storage.PodiumCategory.readAll(function (categories) {
            selectCatGrid.clear();
            selectCatGrid.addRow({ id: allCatsRowKey, name: "All Categories" });
            $.each(categories, function (i, category) {
                selectCatGrid.addRow({ id: category.id, name: category.name });
            });
        });
    }

    selectCatGrid.tableBody.height(140);
    printByCatPopup.onOpen(function () {
        refreshCatList();
    });

    printByCatPopup.body.append(selectCatGrid.html);
    printByCatPopup.addButton("Close", function () {
        printByCatPopup.close();
    });




   
    
    // RESIZE LAYOUT
    layout.resize();

});