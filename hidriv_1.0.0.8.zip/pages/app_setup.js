﻿hidriv.loadPage(function (pageContEle,app) {

    $("body").attr("data-layout", "nomenu");

    var appSettings = new app.ApplicationSettings();
    var applySettings = app.applySettings;
    

    var pageContEle = pageContEle;
    var paragraphs = [
        "Welcome to the HIDRIV Timing App. This is either your first time with us or you just updated to a newer version.",
        "Either way, we need you to choose where you want to store your race files. If you updated, choose the same folder that has all your other race files.<br/> (This can be on your desktop, 'My Documents', or where ever that is safe)",
        "How storage works: You select the location, the app will create folder there call 'HIDRIV FILES' and every time you create a new event it will be stored there.",
        "Ready? (If you still have questions you can go to the Chrome App page and leave a comment)"
    ]
    var cont = $("<div>", { "class": "centered" });
    var p = $("<p>");
    $.each(paragraphs, function (i,par) {
        cont.append(p.clone().html(par));
    });

    var button = $("<button>", {
        html: "Choose Storage Location", click: function () {
            chrome.fileSystem.chooseEntry({ type: "openDirectory" }, function (directoryEntry) {
                chrome.fileSystem.getWritableEntry(directoryEntry, function (writeableEntry) {
                    chrome.fileSystem.getDisplayPath(writeableEntry, function (displayPath) {
                        appSettings.displayPath = displayPath;
                        appSettings.directoryRestoreId = chrome.fileSystem.retainEntry(writeableEntry);
                        applySettings(appSettings);
                    });
                });
            });
        }
    });

    cont.append(button);
    pageContEle.append(cont);
});