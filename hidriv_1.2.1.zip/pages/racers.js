﻿hidriv.loadPage(function (pageContEle, app) {

    $("body").attr("data-layout", "hasmenu");

    var appComponents = app.appComponents;
    var storage = app.currentEvent.storage;
    var cache = app.currentEvent.cache;
    var fileName = app.currentEvent.fileName;


    /************************/
    /*** SAVE & NEW *********/
    /************************/

    var snBtnText = "Save & New";
    var snReopenDelay = 200;
    var getSNHtml = function (snProp) {
        var snChb = $('<input />', { type: "checkbox" })
            .prop('checked', snProp.get())
            .change(function (e) { snProp.set(e.target.checked); });
        var snText = $('<span />', { text: snBtnText });
        var snCont = $('<span />')
            .append($('<label />').append(snChb, snText))
            .addClass('flag');
        return snCont[0];
    }


    var categorySNProp = (function () {
        var snCatDefaultVal = true;
        return { get: function () { return snCatDefaultVal; }, set: function (val) { snCatDefaultVal = val; } };
    })();
    var categorySNHtml = getSNHtml(categorySNProp);

    var racerSNProp = (function () {
        var snRacerDefaultVal = true;
        return { get: function () { return snRacerDefaultVal; }, set: function (val) { snRacerDefaultVal = val; } };
    })();
    var racerSNHtml = getSNHtml(racerSNProp);


    /************************/
    /*** LAYOUT     *********/
    /************************/

    var layout = new appComponents.Layout();
    
    var leftCol = layout.addColumn();
    var categoryGridCell = leftCol.addCell();
    categoryGridCell.setHeight(275);
    var racerGridCell = leftCol.addCell();    
    pageContEle.append(layout.html);
    
    /************************/
    /*** PODIUM CAT GRID ****/
    /************************/

    var checkIfCatNameExists = function (itemId, newName) {
        for (var cid in cache.PodiumCategory.id) {
            if (cache.PodiumCategory.id[cid].id != itemId &&
                (cache.PodiumCategory.id[cid].name + "").toLowerCase() === (newName + "").toLowerCase()) {
                return true;
            }
        }
        return false;
    }

    var categoryGrid = new appComponents.EditorGrid({
        container: categoryGridCell.pad,
        title: "Categories",
        store: storage.PodiumCategory,
        saveCallback: function(actionType){
            if (actionType == "insert" && categorySNProp.get() == true) {
                setTimeout(function () { categoryGrid.popup.open(); }, snReopenDelay);
            }
        },
        gridSettings: {
            selectable: true,
            rowKey: "id",
            name: "catGrid",
            columns: [
                { label: "Id", dataKey: "id", hidden: true },
                { label: "Name", dataKey: "name" },
                { label: "# of Laps", dataKey: "numberOfLaps" }
            ]
        },
        popupSettings: { height: 140, width: 320 },
        formSettings: {
            fields: [
                    { label: "id", dataKey: "id", readonly: true, visible: false },
                    {
                        label: "Name", dataKey: "name", required: true, valid: function (formData) {
                            if (checkIfCatNameExists(formData.id, formData.name)) {
                                return "This category name already exists.";
                            }
                            return true;
                        }
                    },
                    { label: "# of Laps", dataKey: "numberOfLaps", dataType: "int" }
            ]
        }
    }, appComponents.Toolbar, appComponents.Grid, appComponents.Popup, appComponents.Form);


    categoryGrid.popup.onOpen(function () {
        setTimeout(function () {
            var cId = getCategoryIdFormValue();
            if (cId) {
                showCategoryButton(deleteBtnName, true);
                $(categorySNHtml).hide();
            } else {
                showCategoryButton(deleteBtnName, false);
                $(categorySNHtml).show();
            }
        }, 10);
    });

    
    var deleteBtnName = "Delete";
    var deleteCategoryMsg = "This is permanent. Are you sure?";
    var deleteCategoryFailedMsg1 = "Categories with a start time cannot be deleted, a start time must be deleted first.";
    var deleteCategoryFailedMsg2 = "Categories with Racers cannot be deleted, all Racers must be moved to a different Category first.";

    var onCategoryDeleted = function () {
        categoryGrid.refreshGrid();
        categoryGrid.popup.close();
        categoryGrid.form.clear();
        categoryGrid.grid.tableBody.focus();
    }

    var checkIfCategoryStarted = function (catId) {
        return !!cache.CategoryStart.podiumCategoryId[catId];
    }

    var checkIfAnyRacerAttached = function (catId) {
        var result = false;
        $.each(cache.Racer.id, function (id, racer) {
            if (racer.podiumCategoryId == catId) {
                result = true;
            }
        });
        return result;
    }

    var deleteCategory = function (catId, callback) {
        var category = cache.PodiumCategory.id[catId];
        if (category) {
            if (!checkIfCategoryStarted(catId)) {
                if (!checkIfAnyRacerAttached(catId)) {
                    app.confirm(deleteCategoryMsg, function () {
                        storage.PodiumCategory.delete(category, callback);
                    });
                } else {
                    app.messageBox(deleteCategoryFailedMsg2, callback);
                }
            } else {
                app.messageBox(deleteCategoryFailedMsg1, callback);
            }
        } else {
            callback();
        }
    }


    categoryGrid.popup.addButton(deleteBtnName, function () {
        var catId = getCategoryIdFormValue();
        deleteCategory(catId, function () {
            onCategoryDeleted();
        });
    });

    categoryGrid.popup.addButton(snBtnText, function () { });


    var getCategoryIdFormValue = function () {
        return categoryGrid.popup.body.find("input[name='id']").val();
    }

    var getCategoryButton = function (btnName) {
        return categoryGrid.popup.html.find('.button:contains("' + btnName + '")');
    }

    var showCategoryButton = function (btnName, bShow) {
        var btn = getCategoryButton(btnName);
        (bShow != null && bShow == false) ? btn.hide() : btn.show();
    };


    (function () {

        var catSNBtn = getCategoryButton(snBtnText);
        $(catSNBtn).replaceWith(categorySNHtml);

        var deleteBtn = getCategoryButton(deleteBtnName);
        deleteBtn.parent().prepend(deleteBtn);

    })();

    /************************/
    /*** RACER GRID *********/
    /************************/
    
    var getCategoryOptions = function (callback) {
        storage.PodiumCategory.readAll(function (data) {
            var options = [];
            $.each(data, function (i, dataRow) {
                options.push(lib.mapObject(dataRow, { "label": "name", "value": "id" }));
            });
            callback(options);
        });
    }
    var racerGrid = new appComponents.EditorGrid({
        container: racerGridCell.pad,
        title: "Racers",
        store: storage.Racer,
        saveCallback: function (actionType) {
            if (actionType == "insert" && racerSNProp.get() == true) {
                setTimeout(function () { racerGrid.popup.open(); }, snReopenDelay);
            }
        },
        beforeSaveCallback: function (formData, callback) {
            if (formData.id) {
                getRacerLaps(formData.id, function (laps) {

                    var startTimeExists = checkIfStartTimeExists(formData.id);

                    var deleteStart = function (cb) {
                        var warnMsg2 = "This racer has a start time already. If you continue with this change that start time will be unset. Are you sure you want to continue?";
                        app.confirm(warnMsg2, function () {
                            deleteRacerStartTime(formData.id, cb);
                        });
                    }

                    if (laps.length) {
                        var warnMsg1 = "This bib number has laps associated to it. If you continue with this change those laps will be set to no racer. Continue?";
                        app.confirm(warnMsg1, function () {
                            if (startTimeExists) {
                                deleteStart(function () {
                                    setLapsToNoRacer(laps, callback);
                                });
                            } else {
                                setLapsToNoRacer(laps, callback);
                            }
                        });

                    } else if (startTimeExists) {
                        deleteStart(callback);
                    } else {
                        callback();
                    }
                    
                });
            } else {
                callback();
            }
        },
        refreshGrid: function (store, grid) {
            store.readAll(function (data) {
                data = _.sortBy(data, function (obj) { return parseInt(obj.bib); });
                grid.loadData(data,1);
            });
        },
        gridSettings: {
            selectable: true,
            rowKey: "id",
            name: "racerGrid",
            columns: [
                { label: "Id", dataKey: "id", hidden: true },
                { label: "Bib", dataKey: "bib" },
                { label: "F Name", dataKey: "firstName" },
                { label: "L Name", dataKey: "lastName" },
                { label: "Age", dataKey: "age" },
                { label: "Team", dataKey: "team" },
                {
                    label: "Category", dataKey: "podiumCategoryId", getValue: function (podiumCategoryId) {
                        return (podiumCategoryId)?cache.PodiumCategory.id[podiumCategoryId].name:"";
                    }
                }
            ],
            paging: {
                size: 50, callback: function (pageNumber, grid) {
                    storage.Racer.readAll(function (data) {
                        data = _.sortBy(data, function (obj) { return parseInt(obj.bib); });
                        grid.loadData(data, pageNumber);
                    });
                }
            },
            search: {
                title: "BIB",
                callback: function (text, grid) {
                    if (text && text != "") {
                        storage.Racer.readMany("bib", text, function (data) {
                            data = _.sortBy(data, function (obj) { return parseInt(obj.bib); });
                            grid.loadData(data, 1);
                        });
                    } else {
                        storage.Racer.readAll(function (data) {
                            data = _.sortBy(data, function (obj) { return parseInt(obj.bib); });
                            grid.loadData(data, 1);
                        });
                    }
                }
            },
        },
        popupSettings: { height: 300, width: 320 },
        formSettings: {
            fields: [
                { label: "Id", dataKey: "id", readonly: true, hidden: true },
                {
                    label: "Bib", dataKey: "bib", required: true, valid: function (formData) {
                        if (cache.Racer.bib[formData.bib] && cache.Racer.bib[formData.bib].id != formData.id &&
                            cache.Racer.id[cache.Racer.bib[formData.bib].id].bib == formData.bib) {
                            return "This bib number is already assigned to another Racer.";
                        }
                        return true;
                    }
                },
                { label: "F Name", dataKey: "firstName" },
                { label: "L Name", dataKey: "lastName" },
                { label: "Age", dataKey: "age" },
                { label: "Team", dataKey: "team" },
                { label: "Category", dataKey: "podiumCategoryId", type: "select", getOptions: getCategoryOptions, required: true }
            ]
        }
    }, appComponents.Toolbar, appComponents.Grid, appComponents.Popup, appComponents.Form);
    

    racerGrid.toolbar.addButton("Print", function () {
        printByCatPopup.open();
    });


    racerGrid.popup.onOpen(function () {
        setTimeout(function () {
            var id = getRacerIdFormValue();
            if (id) {
                $(racerSNHtml).hide();
                showRacerButton(deleteBtnName, true);
            } else {
                $(racerSNHtml).show();
                showRacerButton(deleteBtnName, false);
            }
        }, 10);
    });



    var deleteBtnName = "Delete";
    var deleteRacerMsg1 = "This is permanent, all laps associated with this racer will be set to blank. Are you sure?";
    var deleteRacerMsg2 = "This racer has a start time already, are you sure you want to delete this racer?";

    var onRacerDeleted = function () {
        racerGrid.refreshGrid();
        racerGrid.popup.close();
        racerGrid.form.clear();
        racerGrid.grid.tableBody.focus();
    }

    var checkIfStartTimeExists = function (racerId) {
        return !!cache.RacerStart.racerId[racerId];
    }

    var getRacerLaps = function (racerId, callback) {
        storage.Lap.readMany("racerId", racerId, function (data) {
            callback(data);
        });
    }

    var setLapsToNoRacer = function (laps, callback) {
        var updateLap = function (lap) {
            i++;
            lap.racerId = ''; lap.bib = '';
            storage.Lap.update(lap, function () {
                if (i < laps.length) {
                    updateLap(laps[i]);
                } else {
                    callback();
                }
            });
        }
        var i = 0;
        if (laps && laps.length) {
            updateLap(laps[i]);
        }
    }

    var deleteRacerStartTime = function (racerId, callback) {
        var racerStart = cache.RacerStart.racerId[racerId];
        if (racerStart) {
            storage.RacerStart.delete(racerStart, callback);
        } else {
            callback();
        }
    }

    var deleteRacer = function (racerId, callback) {
        var racer = cache.Racer.id[racerId];
        if (racer) {
            var deleteRacer = function () { storage.Racer.delete(racer, callback); };
            getRacerLaps(racer.id, function (laps) { 
                if (laps.length) {
                    setLapsToNoRacer(laps, function () {
                        deleteRacer();
                    });
                } else {
                    deleteRacer();
                }
            });
        } else {
            callback();
        }
    }

    racerGrid.popup.addButton(deleteBtnName, function () {

        app.confirm(deleteRacerMsg1, function () {
            var id = getRacerIdFormValue();
            var startTimeExists = checkIfStartTimeExists(id);
            if (startTimeExists) {
                app.confirm(deleteRacerMsg2, function () {

                    deleteRacerStartTime(id, function () {
                        deleteRacer(id, function () {
                            onRacerDeleted();
                        });
                    });

                });
            } else {

                deleteRacer(id, function () {
                    onRacerDeleted();
                });

            }
        });

    });

    racerGrid.popup.addButton(snBtnText, function () { });
    
    storage.PodiumCategory.listen(racerGrid, function () {
        racerGrid.refreshGrid();
    });



    var getRacerIdFormValue = function () {
        return racerGrid.popup.body.find("input[name='id']").val();
    }

    var getRacerButton = function (btnName) {
        return racerGrid.popup.html.find('.button:contains("' + btnName + '")');
    }

    var showRacerButton = function (btnName, bShow) {
        var btn = getRacerButton(btnName);
        (bShow != null && bShow == false) ? btn.hide() : btn.show();
    };


    (function () {

        var racerSNBtn = getRacerButton(snBtnText);
        $(racerSNBtn).replaceWith(racerSNHtml);

        var deleteBtn = getRacerButton(deleteBtnName);
        deleteBtn.parent().prepend(deleteBtn);

    })();



    /*****************************************/
    /****** PRINT BY CAT POPUP ***************/
    /*****************************************/

    var allCatsRowKey = "all-categories";

    var openEventClick = function (rowKey) {
        //printByCatPopup.close();
        var printUrl = "../html/racers-print.html?fileName=" + fileName + "&printType=";
        if (rowKey === allCatsRowKey) {
            printUrl += racersPrintType.all;
        } else {
            printUrl += racersPrintType.byCategory + "&categoryId=" + rowKey;
        }
        window.open(printUrl, "_blank");
    }

    var selectCatGrid = new app.appComponents.Grid({
        selectable: "single",
        rowKey: "id",
        columns: [
            { label: "Id", dataKey: "id", hidden: true },
            { label: "Print Racers (dbl click row)", dataKey: "name", onDblClick: openEventClick }
        ]
    });

    var printByCatPopup = new app.appComponents.Popup({
        height: 200, width: 365
    });

    var refreshCatList = function () {
        storage.PodiumCategory.readAll(function (categories) {
            selectCatGrid.clear();
            selectCatGrid.addRow({ id: allCatsRowKey, name: "All Categories" });
            $.each(categories, function (i, category) {
                selectCatGrid.addRow({ id: category.id, name: category.name });
            });
        });
    }

    selectCatGrid.divBody.height(140);
    printByCatPopup.onOpen(function () {
        refreshCatList();
    });

    printByCatPopup.body.append(selectCatGrid.html);
    printByCatPopup.addButton("Close", function () {
        printByCatPopup.close();
    });





   
    // RESIZE APP COMPONENTS
    layout.resize();
    categoryGrid.grid.size();
    racerGrid.grid.size();

});