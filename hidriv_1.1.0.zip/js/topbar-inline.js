﻿$(function () {
    var currWindow = chrome.app.window.current();
    var maxBtn = $("#window_maximize");
    var restoreBtn = $("#window_minimize");
    var closeBtn = $("#window_close");

    var setMaxRestoreBtn = function () {
        if (currWindow.isMaximized()) {
            maxBtn.hide(); restoreBtn.show();
        } else {
            maxBtn.show(); restoreBtn.hide();
        }
    }

    setMaxRestoreBtn();

    maxBtn.click(function () {
        currWindow.maximize();
        maxBtn.hide(); restoreBtn.show();
    });
    restoreBtn.click(function () {
        currWindow.restore();
        maxBtn.show(); restoreBtn.hide();
    });
    closeBtn.click(function () {
        var popup = new components.Popup({
            height: 100, width: 300
        });
        popup.body.append("<div style='color: #fff; padding: 15px;'>Close the application?</div>");
        popup.addButton("Stay", function () {
            popup.close();
        });
        if (window.fileName) {
            popup.addButton("Close Race", function () {
                closeEventFile();
                popup.close();
            });
        }
        
        popup.addButton("Close App", function () {
            var wins = chrome.app.window.getAll();
            $.each(wins, function (i, w) {
                w.close()
            });
            popup.close();
        });
        
        popup.open();
     
    });
});