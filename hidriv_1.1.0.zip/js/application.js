﻿var Application = function () {
    var self = this; // exposed to external pages
    var _self = {}; // exposed to inner pages
    var pageCont = $("#page_cont");
    var topBar = {
        min: $("#window_minimize"),
        max: $("#window_maximize"),
        close: $("#window_close"),
        title: $("#event_name")
    }
    var startMenu = {
        single: $("#menu_single_start"),
        category: $("#menu_category_start"),
    }
    var settingsFileName = "hidriv.settings";
    var userSettingsFileName = "hidriv_user.settings";
    var applicationSettings;
    var components = new Components();
    var routing;
    var domFileStorage;
    var Storage = MemoryStorage;
    var timing = new Timing();
    var notifications;
    

    _self.eventTypes = [ // do not reorder, used in setMenu
        { name: "Wave Start | One or More Podiums", id: "multi-group-start", description: "Racers start and tracked by podium category. You can start one podium category or choose how many will start at the same time. Overall results and individual podium category results are tracked." },
        { name: "Time Trial | One or More Podiums", id: "single-start", description: "One racer starts at a time. Results are tracked either by podium category and overall." },
    ]
    _self.appThemes = [
        { id: "dark-css", name: "Dark" },
        { id: "light-css", name: "Light" }
    ]
    var dataTemplate = DataTemplate;
    var eventTemplate = dataTemplate.eventTemplate;
    var eventCacheTemplate = dataTemplate.cacheTemplate;

    
    var __construct = function () {
        createDOMFileStorage(function () {

            createRouting();

            _self.getCurrentEvent = getCurrentEvent;
            _self.ApplicationSettings = ApplicationSettings;
            _self.applySettings = applySettings;
            _self.loadAppThemeById = loadAppThemeById;
            _self.applyAppTheme = applyAppTheme;
            _self.components = components;
            _self.createEvent = createEvent;
            _self.listEvents = listEvents;
            _self.openEvent = openEvent;
            _self.exportEvent = exportEvent;
            _self.importEvent = importEvent;
            _self.deleteEvent = deleteEvent;
            _self.eventNameExists = eventNameExists;
            _self.timing = timing;
            _self.topBar = topBar;
            _self.routing = routing;
           
            self.openEvent = openEvent;
            self.currentEvent = _self.currentEvent;
            self.components = components;
            self.lib = lib;
            self.timing = timing;
            self.domFileStorage = domFileStorage;
            self.loadPage = loadPage;

            notifications = new Notifications(self);

            loadSettings(function (settingsExist) {
                routing.loadRoute(settingsExist ? "app_entry" : "app_setup");
            });

            loadAppTheme();
        });

    }

    /********************************/
    /***** EVENTS  ******************/
    /********************************/

    /********************************/
    /***** ACTIONS  *****************/
    /********************************/

    /********************************/
    /***** METHODS  *****************/
    /********************************/

    // storage
    var createDOMFileStorage = function(callback){
        domFileStorage = new DOMFileStorageExt(function () {
            callback();
        });
    }
    
    // settings
    var loadSettings = function (callback) {
        callback(true);        
    }
    var applySettings = function (appSettings) {
        domFileStorage.writeAppSettings(settingsFileName, JSON.stringify(appSettings), function () {
            loadSettings(function (settingsExist) {
                createRouting(settingsExist);
            });
        });
    }
    // user settings
    var loadUserSettings = function (callback) {
        domFileStorage.checkIfSettingsFileExists(userSettingsFileName, function (exists) {
            var us = new UserSettings();
            if (exists) {
                domFileStorage.readUserSettings(userSettingsFileName, function (fileContents) {
                    $.extend(us, JSON.parse(fileContents));
                    callback(us);
                });
            } else {
                callback(us);
            }
        });
    }
    var loadAppThemeById = function (appThemeId) {
        var themes = $.grep(_self.appThemes, function (item) { return item.id == appThemeId; });
        _self.currentTheme = themes.length ? themes[0] : {};
        $(document).find('link#cssTheme').remove();
        var cssThemeUrl = "../css/" + appThemeId + ".css";
        var link = $('<link />', { id: "cssTheme", rel: "stylesheet", href: cssThemeUrl });
        $('head').append(link);
    }
    var loadAppTheme = function () {
        loadUserSettings(function (us) {
            var id = (us && us.appThemeId) ? us.appThemeId : _self.appThemes[0].id;
            loadAppThemeById(id);
        });
    }
    var applyAppTheme = function (appThemeId) {
        loadUserSettings(function (us) {
            us.appThemeId = appThemeId;
            domFileStorage.writeUserSettings(userSettingsFileName, JSON.stringify(us), function () {
                loadAppThemeById(appThemeId);
            });
        });
    }
    // routing
    var createRouting = function () {
        routing = new Routing();       
    }
    var loadPage = function (callback) {
        pageCont.html('');
        callback(pageCont,_self);
    }
    // events
    var createEvent = function (name, date, timingType, callback) {
        var callback = callback ? callback : function () { };
        var ev = {}; $.extend(ev, eventTemplate);
        ev.settings.name = name;
        ev.settings.date = date;
        ev.settings.timingType = timingType;

        domFileStorage.writeEvent(name, JSON.stringify(ev), function () {
            callback();
        });             
    }
    var openEvent = function (name, callback) {
        var callback = callback ? callback : function () { };
        var fileName = name;
        domFileStorage.readEvent(fileName, function (fileContents) {

            _self.currentEvent = new Event(JSON.parse(fileContents), eventCacheTemplate, domFileStorage, eventTemplate);
            self.currentEvent = _self.currentEvent;

            //var ev = JSON.parse(fileContents);
            //var c = {}; $.extend(c, eventCacheTemplate);
            //_self.currentEvent.fileName = fileName;
            //_self.currentEvent.cache = c;
            //_self.currentEvent.settings = ev.settings;
            //_self.currentEvent.storage = new Storage(ev.storage, ev.model, ev.primaryKey, c, function () {
            //    domFileStorage.writeFile(fileName, JSON.stringify(ev), function (data) {
            //        //console.log(JSON.parse(data));
            //    });                
            //});
            callback();
            setStartMenu();
        }, function () { });
    }
    var closeEvent = function () {
        _self.currentEvent = null;

        routing.loadRoute("app_entry");
        topBar.title.html("");
    }
    var deleteEvent = function (name, callback) {
        domFileStorage.removeEvent(name, function () {
            callback();
        });
    }
    var listEvents = function (callback) {
        domFileStorage.listEvents(callback);
    }
    var eventNameExists = function (name, callback) {
        var exists = false;
        listEvents(function (fileEntryList) {
            $.each(fileEntryList, function (i,fileEntry) {
                if (name == fileEntry.name) {
                    exists = true;
                }
            });
            callback(exists);
        });
    }
    var getCurrentEvent = function () {
        return _self.currentEvent;
    }
    var exportEvent = function (fileName, callback) {
        var fileName = fileName;
        domFileStorage.readEvent(fileName, function (fileContents) {
            var mimeType = 'application/json';
            var link = document.createElement('a');
            link.setAttribute('download', fileName+".json");
            link.setAttribute('href', 'data:' + mimeType + ';charset=utf-8,' + encodeURIComponent(fileContents));
            link.click();
            callback();
        }, function () { });
    }
    var importEvent = function (callback) {
        var fileInput = document.createElement('input');
        fileInput.setAttribute("type", "file");
        fileInput.setAttribute("accept", ".json");
        fileInput.addEventListener('change', function (e) {
            // Put the rest of the demo code here.
            var file = fileInput.files[0];
            var reader = new FileReader();
            reader.onload = function (e) {
                try {
                    var json = JSON.parse(reader.result);
                    var name = json.settings.name;
                    eventNameExists(name, function (bool) {
                        if (bool) {
                            self.lib.confirm("READ CAREFULLY!!!! An event with the name of "+name + " already exists. If you import this file the existing event will be overwritten. <br/> Do you want to overwrite?", function (confirmBool) {
                                if (confirmBool) {
                                    domFileStorage.writeEvent(name, reader.result, function () {
                                        callback();
                                    });
                                } else {
                                    self.lib.alert("File did not import.");
                                    callback();
                                }
                            }, { height: 200, width: 350 });
                        } else {
                            domFileStorage.writeEvent(name, reader.result, function () {
                                callback();
                            });
                        }
                    });                    
                    
                }catch(Exception){
                    self.lib.alert("File did not load. Check to make sure this is a race file and try again. If not, then the file may be corrupted. No worries though, shoot us a message on Facebook we will recover the file for you :)", 15000);
                    callback();
                }
            }
            reader.readAsText(file);
        });
        fileInput.click();
    }
    // layout
    var setStartMenu = function () {
        if (_self.currentEvent.settings.timingType == _self.eventTypes[0].id) {
            startMenu.category.show();
            startMenu.single.hide();
        } else {
            startMenu.single.show();
            startMenu.category.hide();            
        }
    }

    /********************************/
    /***** CLASSES  *****************/
    /********************************/
    
    var Routing = function () {
        var onHashChange = function () {
            if (!location.hash) { return; }
            lib.getJS("../pages/" + (location.hash.split("#")[1]) + ".js", function () {
                $(".menu-item").removeClass("active");
                $("[href='" + location.hash + "']").addClass("active");
            });
        }
        var bindEvents = function () {
            $(window).on("hashchange", function () {
                onHashChange();
            });
        }
        this.loadRoute = function (pageName) {
            location.hash = "#" + pageName;
        }
        bindEvents();
    }

    // top bar
    var t = (function () {


        _self.confirm = function (message, callback) {
            var popup = new components.Popup({
                height: 100, width: 300
            });
            popup.body.append("<div class='confirm' style='padding: 15px;'>" + message + "</div>");
            popup.addButton("No", function () {
                popup.close();
            });
            popup.addButton("Yes", function () {
                callback();
                popup.close();
            });
            
            popup.open();
        }

        var showValidationMessage = function () { lib.alert("Only letters and numbers can be typed into the system."); };
        $(document.body).delegate(":input", "keydown", function (e) {
            var k = e.which;
            var isShifted = e.shiftKey;
            var no = ["/", "*", "-", "+"];
            if ((k > 64 && k < 94) || k == 45 || k == 46 || (k > 34 && k < 41) || (k > 96 && k < 123) || k == 8 || (k > 47 && k < 58 && isShifted === false) || (k == 96)) {
                return true;
            } else if (k <= 32 && (k >= 48 || k <= 57) && k != 107 && k != 111 && k != 109) {
                return true;
            }
            showValidationMessage();
            return false;
        });
        $(document).on("keydown", function (e) {
            var k = e.which;
            if ($(e.target).not('input[type="text"], input[type="password"], textarea').is(":input:focus") &&
                k === 8) {
                e.preventDefault();
            }
            else if (!$(e.target).is(":input") &&
                (k === 8 || k === 9) ) {
                e.preventDefault();
            }
        });
        $(document.body).delegate(":input", "paste", function (e) {
            var el = this;
            setTimeout(function () {
                if (!isUserInputValid($(el).val())) {
                    $(el).val('');
                    showValidationMessage();
                }
            }, 100);
        });

        var currWindow = chrome.app.window.current();
        var maxBtn = topBar.max;
        var restoreBtn = topBar.min;
        var closeBtn = topBar.close;

        var setMaxRestoreBtn = function () {
            if (currWindow.isMaximized()) {
                maxBtn.hide(); restoreBtn.show();
            } else {
                maxBtn.show(); restoreBtn.hide();
            }
        }

        setMaxRestoreBtn();

        maxBtn.click(function () {
            currWindow.maximize();
            maxBtn.hide(); restoreBtn.show();
        });
        restoreBtn.click(function () {
            currWindow.restore();
            maxBtn.show(); restoreBtn.hide();
        });
        closeBtn.click(function () {
            var popup = new components.Popup({
                height: 100, width: 300
            });
            popup.body.append("<div class='text-content'>Close the application?</div>");
            popup.addButton("Stay", function () {
                popup.close();
            });
            if (_self.currentEvent && _self.currentEvent.fileName.length) {
                popup.addButton("Close Race", function () {
                    closeEvent();
                    popup.close();
                });
            }

            popup.addButton("Close App", function () {
                var wins = chrome.app.window.getAll();
                $.each(wins, function (i, w) {
                    w.close()
                });
                popup.close();
            });

            popup.open();

        });
    })();

    /********************************/
    /***** MODELS   *****************/
    /********************************/

    var ApplicationSettings = function () {
        this.directoryRestoreId; // chrome directory entry id, used to restore connection to directory
        this.displayPath; // users path to directory
    }

    var UserSettings = function () {
        this.appThemeId = '';
    }

    this.onlineHandler = (function () {

        var stateChangeHandlers = [];
        this.onStateChanged = function (func) {
            stateChangeHandlers.push(func);
        }
        this.isOnline = function () {
            return navigator.onLine;
        }



        window.addEventListener("online", function () {
            $.each(stateChangeHandlers, function (i, f) {
                setCss(true);
                f(true);
            });
        });
        window.addEventListener("offline", function () {
            $.each(stateChangeHandlers, function (i, f) {
                setCss(false);
                f(false);
            });
        });
        var setCss = function (state) {
            $("body").removeClass("online offline");
            $("body").addClass(state ? "online" : "offline");            
        }
        setCss(this.isOnline());

        return this;

    })();

    __construct();

}


var Event = function (eventJSON, eventCacheTemplate, domFileStorage, eventTemplate) {

    


    var self = this;

    var ev = eventJSON;
    var c = $.extend(true, {}, eventCacheTemplate);
    this.cache = c;

    var fileName = ev.settings.name;
    this.fileName = ev.settings.name;
    
    this.settings = ev.settings;
    this.storage = new MemoryStorage(ev.storage, ev.model, ev.primaryKey, c, function () {
        writeToFile();
    });    

    var model = $.extend(true, {}, eventTemplate.model);
    this.model = model;

    // file write queue
    var states = { idle: 0, writing: 1, waiting: 2 };
    var writeState = states.idle;
    var writeToFile = function () {
        writeState = (writeState == states.writing || writeState == states.waiting) ? states.waiting : states.writing;
        domFileStorage.writeEvent(fileName, JSON.stringify(ev), function (data) {
            if (writeState == states.waiting) {
                writeState = states.idle;
                writeToFile();
            } else {
                writeState == states.idle;
            }
        });
    }

}
Application.prototype.Event = Event;


var Notifications = function (app) {
    var self = this;
    var app = app;
    var toolbarBtn = $("#notification_button");
    var flyOutCont = $("#notifications");
    var messageCont = flyOutCont.find(".message-list");
    var closeBtn = $("#notifCloseBtn");

    var __construct = function () {
        flyOutCont.hide();
        if (app.onlineHandler.isOnline()) {
            updateMessages();
        }
                
    }

    // Events
    app.onlineHandler.onStateChanged(function (state) {
        if (state) {
            setTimeout(function () {
                updateMessages();
            }, 20000);            
        }
    });

    // Actions

    closeBtn.click(function(){
        flyOutCont.hide();
    });
    toolbarBtn.click(function () {
        flyOutCont.is(":visible") ? flyOutCont.hide() : flyOutCont.show();
    });

    // Methods
    var updateMessages = function () {
        messageCont.html('');
        $.ajax({
            url: "http://hidriv.com/services/notification.php?action=getAll&app_key=k2HHwsleio2HspqSbdd920ssmc", success: function (result) {
                if (result.data && result.data.length) {
                    $.each(result.data, function (i,res) {
                        messageCont.html('');
                        messageCont.append(new Item(res).html);
                    });
                }                
            }
        });
    }

    var Item = function (dataObj) {
        var div = $("<div>", { "class": "notification-item" });
        var title = $("<div>", { "class": "title", html: dataObj.title });
        var message = $("<div>", { "class": "message", html: " "+dataObj.message });
        var date = $("<div>", { "class": "date", html: (convertToLocaleDateString(dataObj.date) || dataObj.date) });

        div.append(title, date, message);
        this.html = div;
    }
    
    // end
    __construct();
}
